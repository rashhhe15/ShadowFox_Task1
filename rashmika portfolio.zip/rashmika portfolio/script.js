// Example: Alert when user clicks "Download Resume"
document.addEventListener("DOMContentLoaded", () => {
    const resumeLink = document.querySelector('#resume a');
    resumeLink.addEventListener('click', () => {
        alert("Thanks for checking out my resume!");
    });
});
